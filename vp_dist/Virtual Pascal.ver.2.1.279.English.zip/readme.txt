-----------------------
  Virtual Pascal v2.1
    Build 279, Beta
  London, May 2004
-----------------------

Thank you for taking an interest in Virtual Pascal. This document outlines
the installation procedure, and provides last-minute information not
included in the online manuals.


A note about units
------------------

  The VP installer uses SI units for disk space as detailed by this page:
  http://physics.nist.gov/cuu/Units/binary.html

  This means that 1KiB is 1024 bytes and 1MiB is 1024*1024 bytes.  Using
  the old-fashioned KB and MB is ambiguous as it sometimes means 1000
  and sometimes 1024.  Expect to see this more often in the future :)


Installation
------------

To install this version of Virtual Pascal 2.1

 - Extract all archives you have downloaded to a temporary directory, not
   the one in which Virtual Pascal is to be installed. (Do not extract
   the inner archives called W*.RAR, O*.Rar, L*.Rar, and A*.Rar; the
   installation program will do this for you).

 - Run the appropriate installation program, SetupW32.Exe for Windows,
   SetupOs2.Exe for OS/2 and setuplnx for Linux. This program is a text
   mode Turbo Vision application compiled from the same source code for
   all platforms - of course using Virtual Pascal to do so.

 - The licence agreement is displayed. Read it and press Alt-I or select the
   Install option from the File menu to start the installation.

 - The welcome page of the installation wizard is displayed.

   Press the Next button to proceed.

 - On the next page, the pre-selection screen, choose from one of 3 default
   options. Select "Full Install" to install all parts of the product and
   "Everything That's Free" to install all of the free stuff.  Choose the
   "Custom Setup" option to pick and choose.

   Note: If you choose Full Install or Custom Setup, you will need an
   original copy of Borland Pascal and/or Delphi in order to complete
   the installation.

   Press the Next button to continue.

 - If you chose Custom Setup, the next dialog allows you to choose
   individual components to install. Review the settings, by using the
   Detail button to review the inclusion of sub-components.

   Press the Next button to continue.

 - In Windows and OS/2, the next screen is used to select the drive to which
   Virtual Pascal 2.1 should be installed; if a drive does not have enough
   space to install the selected options, the drive space indicator will
   be red. Ifinstalling to such a drive, you can insist that there is enough
   space and continue anyway. The directory will be chosen on the next
   screen.

   Press the Next button to continue.

 - Choose your preference regarding the case of directory names. You can
   choose UPPER case, lower case or Mixed Case. All directories created
   by the installation program will use the choice selected here.

   Press the Next button to continue.

 - Enter the installation directory, excluding drive letter. This can be any
   directory (spaces not allowed), whether it exists or not. If it is a new
   directory, the installation program will ask if it should be created for
   you.  In Linux, the installation directory should start with a /, such
   as /usr/local/vp21.

   Press the Next button to continue.

 - If any of the components requiring original source code were included
   in the selection (Object Windows Library, Visual Class Library) you will
   be prompted to enter the path to the original sources.

   Press the Next button to continue.

   If any of the required source files are not found, an error message
   will be displayed and you will be prompted to enter a new path.


While you wait
--------------

  The installation program will now unpack the selected archives and copy
  (and patch, where required) the selected source code.

  When it has finished, please read the rest of this readme file. Or, since
  all of the platforms supported by VP are multitasking systems you can just
  read it while the installation program is running. The OS/2 programs are
  installed to the bin.os2 directory, the Win32 programs to bin.w32 and the
  files used for the experimental Linux support to bin.lnx.

  Full information about Virtual Pascal, the directory structure, etc. is
  included as .PDF manuals readable by the free Adobe Acrobat viewer v3.0
  or later. These files can be found in the DOC directory.


Acknowledgements
----------------

  This version of Virtual Pascal is dedicated to my dear and loving wife,
  Mamta. She supports me in everything I do - if it wasn't for her, VP
  would not have happened so you can thank her too :)

  I also wish to thank everybody who has contributed to VP over the years.
  Many, many people have downloaded and used the software (around 125.000!)
  and several dedicated individuals have contributed significantly.  Thanks!


Upgrade Patches
---------------

  The upgrade patches for non-VP source code included with this software is
  version specific. This means that the update program requires an original,
  unmodified source file in order to be able to perform the update.

  The following versions can be upgraded to compatibility with Virtual
  Pascal:
    Visual Component Library (Requires Borland Delphi)
      Delphi v1.00
      Delphi v2.00-v2.01
      Delphi v3.00
      Delphi v4.01
      Delphi v5.00
      Delphi v5.01

    Object Windows Library (Requires Borland Delphi or Pascal)
      v7.00 (BP v7.0 or BP for Windows)
      v8.00 (Delphi v1.00)
      v8.01 (Delphi v1.01)


Known Issues
------------

  This release of Virtual Pascal v2.1 has several known issues.  Please
  create an account and log in to the VP Bugs Database for the latest
  information.

  The database can be accessed at http://www.vpascal.com/bugs.


What is new
-----------

  This build adds new features and fixes several problems reported in the
  previous builds 243, 270 and 274.  For a complete list of new features and 
  fixes, please refer to the whatsnew.txt file.


Feedback
--------

  I welcome your feedback!  If you have suggestions for a new feature or
  want to report a bug, please create an account in the VP Bugs Database
  and file it there.

  The database can be accessed at http://www.vpascal.com/bugs.


Licence
-------

  Virtual Pascal is Copyright (C) Virtual Pascal 1999-2004 by vpascal.com
  and must not be distributed or copied except as allowed by the terms
  of the licence.

  Please refer to licence.txt for the full licence.


Manuals
-------

  Comprehensive manuals covering the use of Virtual Pascal v2.1 and a
  completelanguage reference are included as Adobe Portable Document
  Format (PDF) files in the DOC directory.

  The User's guide, vp21user.pdf, introduces the installation program,
  features of VP v2, IDE usage, debugger, and cross-platform support.

  The Language Reference, vp21lang.pdf, provides in-depth documentation
  of the Pascal language as implemented by Virtual Pascal.

  Both documents can be viewed using the widely available free Adobe Acrobat
  Reader v3.0 or later, and can be printed to provide a hard copy manual.
  Download Acrobat Reader from Adobe's web site. The manuals are secured
  from changing, although users of Adobe Exchange can add notes to the
  documents.  The User Manual is also included in plain text format, as
  vp21user.txt for easier viewing and searching on less powerful machines.


More information
----------------

  To get more information about VP, I encourage you to set up an account at
  www.vpascal.com - make use of the forums, etc.
  
  You can also join the Virtual Pascal mailing list hosted on Yahoo!
  To subscribe to it, go to http://groups.yahoo.com/group/vpascal/join
  or send an email to vpascal-subscribe@yahoogroups.com.


Contact Address
---------------

  To reach me via email (don't expect a reply: I get a lot :), send email to
  allan@vpascal.com.
  
  News, forums, etc can all be reached via the VP web site at http://www.vpascal.com


Trademarks
----------

  Company names, brand names and product names are trademarks or registered
  trademarks of their respective holders.


Copyright (C) 1999-2004 Allan Mertner and vpascal.com


